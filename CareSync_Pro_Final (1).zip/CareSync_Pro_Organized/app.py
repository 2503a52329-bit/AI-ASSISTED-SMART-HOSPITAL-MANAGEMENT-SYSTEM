from flask import Flask, render_template, request, redirect, url_for, flash, send_file, abort
from werkzeug.utils import secure_filename
from pathlib import Path
import sqlite3, uuid
from datetime import date, datetime, timedelta

app = Flask(__name__)
app.secret_key = 'caresync-local-demo-change-before-deployment'
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10 MB per upload
DB = 'hospital.db'
UPLOAD_DIR = Path('instance') / 'medical_reports'
ALLOWED_REPORT_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

def db():
    conn = sqlite3.connect(DB)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS patients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,age INTEGER,gender TEXT,phone TEXT,blood_group TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS doctors(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,specialization TEXT,phone TEXT,status TEXT DEFAULT 'Available');
    CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,doctor_id INTEGER,appointment_date TEXT,appointment_time TEXT,reason TEXT,status TEXT DEFAULT 'Scheduled',FOREIGN KEY(patient_id) REFERENCES patients(id),FOREIGN KEY(doctor_id) REFERENCES doctors(id));
    CREATE TABLE IF NOT EXISTS ehr(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,notes TEXT,record_date TEXT,FOREIGN KEY(patient_id) REFERENCES patients(id));
    CREATE TABLE IF NOT EXISTS medicines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,stock INTEGER,price REAL);
    CREATE TABLE IF NOT EXISTS lab_tests(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,test_name TEXT,test_date TEXT,status TEXT DEFAULT 'Pending',result TEXT,FOREIGN KEY(patient_id) REFERENCES patients(id));
    CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,description TEXT,amount REAL,bill_date TEXT,status TEXT DEFAULT 'Unpaid',FOREIGN KEY(patient_id) REFERENCES patients(id));
    CREATE TABLE IF NOT EXISTS rooms(id INTEGER PRIMARY KEY AUTOINCREMENT,room_no TEXT,room_type TEXT,status TEXT DEFAULT 'Available',patient_id INTEGER);
    CREATE TABLE IF NOT EXISTS emergency(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_name TEXT,phone TEXT,emergency_type TEXT,priority TEXT,status TEXT DEFAULT 'Active',created_at TEXT);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,message TEXT NOT NULL,level TEXT DEFAULT 'info',created_at TEXT,read_status INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT NOT NULL,details TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,email TEXT);
    CREATE TABLE IF NOT EXISTS admissions(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER NOT NULL,room_id INTEGER NOT NULL,admission_date TEXT NOT NULL,discharge_date TEXT,status TEXT DEFAULT 'Admitted',FOREIGN KEY(patient_id) REFERENCES patients(id),FOREIGN KEY(room_id) REFERENCES rooms(id));
    ''')
    if conn.execute('SELECT COUNT(*) FROM doctors').fetchone()[0] == 0:
        conn.executemany('INSERT INTO doctors(name,specialization,phone,status) VALUES(?,?,?,?)',[
            ('Dr. Ananya Rao','Cardiology','9876500011','Available'),('Dr. Arjun Kumar','General Medicine','9876500022','Available'),('Dr. Meera Shah','Pediatrics','9876500033','Busy'),('Dr. Rahul Verma','Orthopedics','9876500044','Available')])
    if conn.execute('SELECT COUNT(*) FROM patients').fetchone()[0] == 0:
        conn.executemany('INSERT INTO patients(name,age,gender,phone,blood_group,created_at) VALUES(?,?,?,?,?,?)',[
            ('Aarav Reddy',34,'Male','9000000001','O+',str(date.today())),('Diya Sharma',26,'Female','9000000002','A+',str(date.today())),('Kiran Patel',45,'Male','9000000003','B+',str(date.today()))])
    if conn.execute('SELECT COUNT(*) FROM medicines').fetchone()[0] == 0:
        conn.executemany('INSERT INTO medicines(name,category,stock,price) VALUES(?,?,?,?)',[
            ('Paracetamol','Tablet',120,25),('Amoxicillin','Capsule',45,80),('ORS','Sachet',60,20),('Vitamin D','Tablet',18,110)])
    if conn.execute('SELECT COUNT(*) FROM rooms').fetchone()[0] == 0:
        conn.executemany('INSERT INTO rooms(room_no,room_type,status) VALUES(?,?,?)',[
            ('101','General','Available'),('102','General','Occupied'),('ICU-1','ICU','Available'),('ICU-2','ICU','Available'),('201','Private','Occupied'),('202','Private','Available')])
    ensure_column(conn, 'medicines', 'expiry_date', 'TEXT')
    ensure_column(conn, 'patients', 'patient_code', 'TEXT')
    ensure_column(conn, 'emergency', 'symptoms', 'TEXT')
    ensure_column(conn, 'emergency', 'verification_status', "TEXT DEFAULT 'Awaiting Nurse Review'")
    ensure_column(conn, 'emergency', 'nurse_name', 'TEXT')
    ensure_column(conn, 'emergency', 'nurse_notes', 'TEXT')
    # Emergency workflow fields; ensure_column keeps existing hospital.db files usable.
    for column, definition in [
        ('patient_id', 'INTEGER'), ('first_visit', "TEXT DEFAULT 'Yes'"),
        ('previous_hospital', 'TEXT'), ('emergency_contact_name', 'TEXT'),
        ('emergency_contact_phone', 'TEXT'), ('heart_rate', 'TEXT'),
        ('blood_pressure', 'TEXT'), ('spo2', 'TEXT'), ('temperature', 'TEXT'),
        ('respiratory_rate', 'TEXT'), ('vitals_source', 'TEXT'),
        ('assigned_doctor_id', 'INTEGER'), ('updated_at', 'TEXT')
    ]:
        ensure_column(conn, 'emergency', column, definition)
    conn.execute('''CREATE TABLE IF NOT EXISTS emergency_reports(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        emergency_id INTEGER NOT NULL,
        patient_id INTEGER,
        report_type TEXT NOT NULL,
        hospital_name TEXT NOT NULL,
        report_date TEXT,
        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL,
        uploaded_at TEXT NOT NULL,
        FOREIGN KEY(emergency_id) REFERENCES emergency(id)
    )''')
    conn.execute("UPDATE patients SET patient_code='CS-' || printf('%05d',id) WHERE patient_code IS NULL OR patient_code=''")
    conn.commit(); conn.close()


def ensure_column(conn, table, column, definition):
    existing = [r['name'] for r in conn.execute(f'PRAGMA table_info({table})').fetchall()]
    if column not in existing:
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')

def log_action(conn, action, details=''):
    conn.execute('INSERT INTO audit_logs(action,details,created_at) VALUES(?,?,?)',(action, details, str(date.today())))

def notify(conn, title, message, level='info'):
    conn.execute('INSERT INTO notifications(title,message,level,created_at) VALUES(?,?,?,?)',(title, message, level, str(date.today())))

@app.route('/')
def dashboard():
    conn=db()
    today=str(date.today())
    stats={
        'patients':conn.execute('SELECT COUNT(*) FROM patients').fetchone()[0],
        'doctors':conn.execute('SELECT COUNT(*) FROM doctors').fetchone()[0],
        'appointments':conn.execute('SELECT COUNT(*) FROM appointments').fetchone()[0],
        'today_appointments':conn.execute('SELECT COUNT(*) FROM appointments WHERE appointment_date=?',(today,)).fetchone()[0],
        'available':conn.execute("SELECT COUNT(*) FROM doctors WHERE status='Available'").fetchone()[0],
        'beds':conn.execute("SELECT COUNT(*) FROM rooms WHERE status='Available'").fetchone()[0],
        'occupied':conn.execute("SELECT COUNT(*) FROM rooms WHERE status='Occupied'").fetchone()[0],
        'pending_labs':conn.execute("SELECT COUNT(*) FROM lab_tests WHERE status='Pending'").fetchone()[0],
        'low_stock':conn.execute("SELECT COUNT(*) FROM medicines WHERE stock < 25").fetchone()[0],
        'expiring':conn.execute("SELECT COUNT(*) FROM medicines WHERE expiry_date IS NOT NULL AND expiry_date<>'' AND date(expiry_date)<=date('now','+60 day') AND date(expiry_date)>=date('now')").fetchone()[0],
        'revenue':conn.execute("SELECT COALESCE(SUM(amount),0) FROM bills WHERE status='Paid'").fetchone()[0],
        'admissions':conn.execute("SELECT COUNT(*) FROM admissions WHERE status='Admitted'").fetchone()[0],
    }
    total_rooms=stats['beds']+stats['occupied']
    stats['occupancy']=round(stats['occupied']*100/total_rooms) if total_rooms else 0
    recent=conn.execute('''SELECT a.*,p.name patient,d.name doctor,d.specialization FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN doctors d ON a.doctor_id=d.id ORDER BY a.appointment_date DESC,a.appointment_time DESC LIMIT 6''').fetchall()
    monthly=conn.execute("SELECT substr(bill_date,1,7) month,COALESCE(SUM(amount),0) total FROM bills WHERE status='Paid' GROUP BY substr(bill_date,1,7) ORDER BY month DESC LIMIT 6").fetchall()
    alerts=[]
    if stats['low_stock']: alerts.append({'level':'warning','icon':'!','title':'Medicine stock running low','message':f"{stats['low_stock']} medicine item(s) below reorder threshold",'url':'/pharmacy'})
    if stats['pending_labs']: alerts.append({'level':'info','icon':'◉','title':'Lab work awaiting completion','message':f"{stats['pending_labs']} test(s) are still pending",'url':'/laboratory'})
    if stats['expiring']: alerts.append({'level':'danger','icon':'⌁','title':'Medicine expiry approaching','message':f"{stats['expiring']} medicine item(s) expire within 60 days",'url':'/pharmacy'})
    active_emergencies=conn.execute("SELECT COUNT(*) FROM emergency WHERE status='Active'").fetchone()[0]
    if active_emergencies: alerts.append({'level':'danger','icon':'⚠','title':'Active emergency cases','message':f'{active_emergencies} case(s) require emergency desk follow-up','url':'/emergency'})
    conn.close()
    labels=[r['month'] for r in reversed(monthly)]
    values=[float(r['total']) for r in reversed(monthly)]
    return render_template('dashboard.html',stats=stats,recent=recent,alerts=alerts,today=today,revenue_labels=labels,revenue_values=values)

@app.route('/patients',methods=['GET','POST'])
def patients():
    conn=db()
    if request.method=='POST':
        cur=conn.execute('INSERT INTO patients(name,age,gender,phone,blood_group,created_at) VALUES(?,?,?,?,?,?)',(request.form['name'],request.form['age'],request.form['gender'],request.form['phone'],request.form['blood_group'],str(date.today())))
        patient_code=f'CS-{cur.lastrowid:05d}'
        conn.execute('UPDATE patients SET patient_code=? WHERE id=?',(patient_code,cur.lastrowid))
        log_action(conn,'Patient registered',f'{patient_code}: {request.form["name"]}')
        notify(conn,'New patient registered',f'{request.form["name"]} was added to patient records.','success')
        conn.commit(); conn.close(); flash('Patient registered successfully.'); return redirect(url_for('patients'))
    q=request.args.get('q','')
    rows=conn.execute('SELECT * FROM patients WHERE name LIKE ? OR phone LIKE ? ORDER BY id DESC',(f'%{q}%',f'%{q}%')).fetchall(); conn.close()
    return render_template('patients.html',patients=rows,q=q)

@app.route('/patients/delete/<int:id>')
def delete_patient(id):
    conn=db(); conn.execute('DELETE FROM appointments WHERE patient_id=?',(id,)); conn.execute('DELETE FROM ehr WHERE patient_id=?',(id,)); conn.execute('DELETE FROM patients WHERE id=?',(id,)); conn.commit(); conn.close(); return redirect(url_for('patients'))

@app.route('/doctors',methods=['GET','POST'])
def doctors():
    conn=db()
    if request.method=='POST':
        conn.execute('INSERT INTO doctors(name,specialization,phone,status) VALUES(?,?,?,?)',(request.form['name'],request.form['specialization'],request.form['phone'],request.form['status']))
        conn.commit(); conn.close(); flash('Doctor added successfully.'); return redirect(url_for('doctors'))
    rows=conn.execute('SELECT * FROM doctors ORDER BY id DESC').fetchall(); conn.close(); return render_template('doctors.html',doctors=rows)

@app.route('/doctor/status/<int:id>')
def doctor_status(id):
    conn=db(); row=conn.execute('SELECT status FROM doctors WHERE id=?',(id,)).fetchone(); new='Busy' if row and row['status']=='Available' else 'Available'; conn.execute('UPDATE doctors SET status=? WHERE id=?',(new,id)); conn.commit(); conn.close(); return redirect(url_for('doctors'))

@app.route('/appointments',methods=['GET','POST'])
def appointments():
    conn=db()
    if request.method=='POST':
        conflict=conn.execute("SELECT id FROM appointments WHERE doctor_id=? AND appointment_date=? AND appointment_time=? AND status='Scheduled'",(request.form['doctor_id'],request.form['appointment_date'],request.form['appointment_time'])).fetchone()
        if conflict:
            conn.close(); flash('This doctor already has an appointment at that date and time. Choose another slot.'); return redirect(url_for('appointments'))
        conn.execute('INSERT INTO appointments(patient_id,doctor_id,appointment_date,appointment_time,reason,status) VALUES(?,?,?,?,?,?)',(request.form['patient_id'],request.form['doctor_id'],request.form['appointment_date'],request.form['appointment_time'],request.form['reason'],'Scheduled'))
        log_action(conn,'Appointment booked',f"Patient ID {request.form['patient_id']} with doctor ID {request.form['doctor_id']}")
        notify(conn,'Appointment booked','A new appointment has been scheduled.','success')
        conn.commit(); conn.close(); flash('Appointment booked successfully.'); return redirect(url_for('appointments'))
    rows=conn.execute('''SELECT a.*,p.name patient,d.name doctor,d.specialization FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN doctors d ON a.doctor_id=d.id ORDER BY a.appointment_date DESC,a.appointment_time DESC''').fetchall()
    pats=conn.execute('SELECT * FROM patients ORDER BY name').fetchall(); docs=conn.execute('SELECT * FROM doctors ORDER BY name').fetchall(); conn.close()
    return render_template('appointments.html',appointments=rows,patients=pats,doctors=docs)

@app.route('/appointment/complete/<int:id>')
def complete_appointment(id):
    conn=db(); conn.execute("UPDATE appointments SET status='Completed' WHERE id=?",(id,)); conn.commit(); conn.close(); return redirect(url_for('appointments'))

@app.route('/admissions', methods=['GET','POST'])
def admissions():
    conn=db()
    if request.method=='POST':
        patient_id=request.form.get('patient_id','').strip(); room_id=request.form.get('room_id','').strip(); admit_date=request.form.get('admission_date') or str(date.today())
        room=conn.execute("SELECT * FROM rooms WHERE id=? AND status='Available'",(room_id,)).fetchone()
        patient=conn.execute('SELECT * FROM patients WHERE id=?',(patient_id,)).fetchone()
        already=conn.execute("SELECT id FROM admissions WHERE patient_id=? AND status='Admitted'",(patient_id,)).fetchone()
        if not patient or not room or already:
            conn.close(); flash('Admission could not be completed. Check patient, bed availability and existing admissions.'); return redirect(url_for('admissions'))
        conn.execute("INSERT INTO admissions(patient_id,room_id,admission_date,status) VALUES(?,?,?,'Admitted')",(patient_id,room_id,admit_date))
        conn.execute("UPDATE rooms SET status='Occupied',patient_id=? WHERE id=?",(patient_id,room_id))
        log_action(conn,'Patient admitted',f"{patient['name']} assigned to room {room['room_no']}")
        notify(conn,'New patient admission',f"{patient['name']} admitted to room {room['room_no']}",'success')
        conn.commit(); conn.close(); flash('Patient admitted and bed allocated successfully.'); return redirect(url_for('admissions'))
    active=conn.execute("SELECT a.*,p.name patient,p.patient_code,r.room_no,r.room_type,CAST(julianday('now')-julianday(a.admission_date) AS INTEGER) days FROM admissions a JOIN patients p ON p.id=a.patient_id JOIN rooms r ON r.id=a.room_id WHERE a.status='Admitted' ORDER BY a.id DESC").fetchall()
    discharged=conn.execute("SELECT a.*,p.name patient,r.room_no FROM admissions a JOIN patients p ON p.id=a.patient_id JOIN rooms r ON r.id=a.room_id WHERE a.status='Discharged' ORDER BY a.id DESC LIMIT 10").fetchall()
    patients=conn.execute("SELECT * FROM patients WHERE id NOT IN (SELECT patient_id FROM admissions WHERE status='Admitted') ORDER BY name").fetchall()
    rooms=conn.execute("SELECT * FROM rooms WHERE status='Available' ORDER BY room_no").fetchall()
    all_rooms=conn.execute('SELECT * FROM rooms ORDER BY room_no').fetchall(); conn.close()
    return render_template('admissions.html',active=active,discharged=discharged,patients=patients,rooms=rooms,all_rooms=all_rooms,today=str(date.today()))

@app.route('/admission/discharge/<int:id>', methods=['POST'])
def discharge_patient(id):
    conn=db(); admission=conn.execute("SELECT a.*,p.name patient,r.room_no FROM admissions a JOIN patients p ON p.id=a.patient_id JOIN rooms r ON r.id=a.room_id WHERE a.id=? AND a.status='Admitted'",(id,)).fetchone()
    if admission:
        conn.execute("UPDATE admissions SET status='Discharged',discharge_date=? WHERE id=?",(str(date.today()),id))
        conn.execute("UPDATE rooms SET status='Available',patient_id=NULL WHERE id=?",(admission['room_id'],))
        log_action(conn,'Patient discharged',f"{admission['patient']} discharged from room {admission['room_no']}")
        notify(conn,'Patient discharged',f"{admission['patient']} discharged; room {admission['room_no']} is available.",'success')
        flash('Patient discharged and bed marked available.')
    else: flash('Active admission not found.')
    conn.commit(); conn.close(); return redirect(url_for('admissions'))

@app.route('/ehr',methods=['GET','POST'])
def ehr():
    conn=db()
    if request.method=='POST':
        conn.execute('INSERT INTO ehr(patient_id,notes,record_date) VALUES(?,?,?)',(request.form['patient_id'],request.form['notes'],str(date.today())))
        conn.commit(); conn.close(); flash('Health record saved.'); return redirect(url_for('ehr'))
    records=conn.execute('SELECT e.*,p.name patient FROM ehr e JOIN patients p ON e.patient_id=p.id ORDER BY e.id DESC').fetchall(); pats=conn.execute('SELECT * FROM patients ORDER BY name').fetchall(); conn.close(); return render_template('ehr.html',records=records,patients=pats)

@app.route('/ai-assistant',methods=['GET','POST'])
def ai_assistant():
    suggestion=None
    if request.method=='POST':
        text=request.form['symptoms'].lower()
        rules=[(['chest','heart','breath'],'Cardiology'),(['bone','joint','fracture','knee','back'],'Orthopedics'),(['child','baby','kid'],'Pediatrics'),(['skin','rash'],'Dermatology')]
        suggestion='General Medicine'
        for words,dept in rules:
            if any(w in text for w in words): suggestion=dept; break
    return render_template('ai.html',suggestion=suggestion)

@app.route('/pharmacy',methods=['GET','POST'])
def pharmacy():
    conn=db()
    if request.method=='POST':
        conn.execute('INSERT INTO medicines(name,category,stock,price,expiry_date) VALUES(?,?,?,?,?)',(request.form['name'],request.form['category'],request.form['stock'],request.form['price'],request.form.get('expiry_date') or None))
        log_action(conn,'Medicine added',request.form['name'])
        if int(request.form['stock']) < 25: notify(conn,'Low medicine stock',f"{request.form['name']} has low stock.",'warning')
        conn.commit(); conn.close(); flash('Medicine added to pharmacy stock.'); return redirect(url_for('pharmacy'))
    rows=conn.execute('SELECT * FROM medicines ORDER BY name').fetchall()
    low_stock=conn.execute('SELECT COUNT(*) FROM medicines WHERE stock<25').fetchone()[0]
    conn.close(); return render_template('pharmacy.html',medicines=rows,low_stock=low_stock)

@app.route('/medicine/stock/<int:id>',methods=['POST'])
def medicine_stock(id):
    conn=db(); conn.execute('UPDATE medicines SET stock=? WHERE id=?',(request.form['stock'],id)); conn.commit(); conn.close(); return redirect(url_for('pharmacy'))

@app.route('/laboratory',methods=['GET','POST'])
def laboratory():
    conn=db()
    if request.method=='POST':
        conn.execute('INSERT INTO lab_tests(patient_id,test_name,test_date,status,result) VALUES(?,?,?,?,?)',(request.form['patient_id'],request.form['test_name'],str(date.today()),'Pending',''))
        conn.commit(); conn.close(); flash('Lab test requested.'); return redirect(url_for('laboratory'))
    rows=conn.execute('SELECT l.*,p.name patient FROM lab_tests l JOIN patients p ON l.patient_id=p.id ORDER BY l.id DESC').fetchall(); pats=conn.execute('SELECT * FROM patients ORDER BY name').fetchall(); conn.close(); return render_template('laboratory.html',tests=rows,patients=pats)

@app.route('/lab/complete/<int:id>',methods=['POST'])
def lab_complete(id):
    conn=db(); conn.execute("UPDATE lab_tests SET status='Completed',result=? WHERE id=?",(request.form['result'],id)); conn.commit(); conn.close(); return redirect(url_for('laboratory'))

@app.route('/lab/report/<int:id>')
def lab_report_download(id):
    from io import BytesIO
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas
    conn=db()
    row=conn.execute('SELECT l.*,p.name patient,p.patient_code,p.age,p.gender FROM lab_tests l JOIN patients p ON p.id=l.patient_id WHERE l.id=?',(id,)).fetchone()
    conn.close()
    if not row:
        flash('Lab report not found.'); return redirect(url_for('laboratory'))
    if row['status'] != 'Completed':
        flash('The report can be downloaded after the lab test is marked completed.'); return redirect(url_for('laboratory'))
    buffer=BytesIO(); pdf=canvas.Canvas(buffer,pagesize=A4); width,height=A4
    pdf.setTitle(f'CareSync Lab Report {id}')
    pdf.setFont('Helvetica-Bold',20); pdf.drawString(20*mm,height-25*mm,'CareSync Hospital')
    pdf.setFont('Helvetica',10); pdf.drawString(20*mm,height-32*mm,'LABORATORY TEST REPORT • Academic demonstration')
    pdf.line(20*mm,height-37*mm,width-20*mm,height-37*mm)
    y=height-55*mm
    pdf.setFont('Helvetica-Bold',13); pdf.drawString(20*mm,y,'Patient details'); y-=10*mm
    pdf.setFont('Helvetica',11)
    for label,value in [('Report ID',f'LAB-{row["id"]:05d}'),('Patient',row['patient']),('Patient ID',row['patient_code'] or f'CS-{row["patient_id"]:05d}'),('Age / Gender',f'{row["age"] or "—"} / {row["gender"] or "—"}'),('Test name',row['test_name']),('Test date',row['test_date']),('Status',row['status'])]:
        pdf.drawString(22*mm,y,f'{label}: {value or "—"}'); y-=8*mm
    y-=6*mm; pdf.setFont('Helvetica-Bold',13); pdf.drawString(20*mm,y,'Recorded result'); y-=10*mm
    pdf.setFont('Helvetica',11)
    result=str(row['result'] or 'No result recorded')
    for line in result.splitlines() or ['']:
        while len(line)>95:
            pdf.drawString(22*mm,y,line[:95]); line=line[95:]; y-=7*mm
        pdf.drawString(22*mm,y,line); y-=7*mm
    pdf.setFont('Helvetica-Oblique',9); pdf.drawString(20*mm,20*mm,'This report reproduces information entered into the demo system; it is not a substitute for clinician interpretation.')
    pdf.save(); buffer.seek(0)
    return send_file(buffer,mimetype='application/pdf',as_attachment=True,download_name=f'CareSync_Lab_Report_{id}.pdf')

@app.route('/billing',methods=['GET','POST'])
def billing():
    conn=db()
    if request.method=='POST':
        conn.execute('INSERT INTO bills(patient_id,description,amount,bill_date,status) VALUES(?,?,?,?,?)',(request.form['patient_id'],request.form['description'],request.form['amount'],str(date.today()),'Unpaid'))
        conn.commit(); conn.close(); flash('Bill generated.'); return redirect(url_for('billing'))
    rows=conn.execute('SELECT b.*,p.name patient FROM bills b JOIN patients p ON b.patient_id=p.id ORDER BY b.id DESC').fetchall(); pats=conn.execute('SELECT * FROM patients ORDER BY name').fetchall(); total=conn.execute("SELECT COALESCE(SUM(amount),0) FROM bills WHERE status='Paid'").fetchone()[0]; conn.close(); return render_template('billing.html',bills=rows,patients=pats,total=total)

@app.route('/bill/pay/<int:id>')
def bill_pay(id):
    conn=db(); conn.execute("UPDATE bills SET status='Paid' WHERE id=?",(id,)); conn.commit(); conn.close(); return redirect(url_for('billing'))

@app.route('/bill/invoice/<int:id>')
def bill_invoice_download(id):
    from io import BytesIO
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas
    conn=db()
    row=conn.execute('SELECT b.*,p.name patient,p.patient_code,p.phone FROM bills b JOIN patients p ON p.id=b.patient_id WHERE b.id=?',(id,)).fetchone()
    conn.close()
    if not row:
        flash('Invoice not found.'); return redirect(url_for('billing'))
    buffer=BytesIO(); pdf=canvas.Canvas(buffer,pagesize=A4); width,height=A4
    pdf.setTitle(f'CareSync Invoice {id}')
    pdf.setFont('Helvetica-Bold',22); pdf.drawString(20*mm,height-25*mm,'CareSync Hospital')
    pdf.setFont('Helvetica',10); pdf.drawString(20*mm,height-32*mm,'PATIENT INVOICE • Academic demonstration')
    pdf.line(20*mm,height-38*mm,width-20*mm,height-38*mm)
    y=height-58*mm; pdf.setFont('Helvetica-Bold',14); pdf.drawString(20*mm,y,f'Invoice: INV-{row["id"]:05d}')
    y-=14*mm; pdf.setFont('Helvetica',11)
    for label,value in [('Invoice date',row['bill_date']),('Patient',row['patient']),('Patient ID',row['patient_code'] or f'CS-{row["patient_id"]:05d}'),('Phone',row['phone'] or '—'),('Payment status',row['status'])]:
        pdf.drawString(22*mm,y,f'{label}: {value}'); y-=9*mm
    y-=8*mm; pdf.setFont('Helvetica-Bold',11); pdf.drawString(22*mm,y,'Description'); pdf.drawRightString(width-22*mm,y,'Amount'); y-=5*mm; pdf.line(20*mm,y,width-20*mm,y); y-=12*mm
    pdf.setFont('Helvetica',11); pdf.drawString(22*mm,y,str(row['description'])[:90]); pdf.drawRightString(width-22*mm,y,f'INR {float(row["amount"]):,.2f}')
    y-=15*mm; pdf.line(20*mm,y,width-20*mm,y); y-=12*mm; pdf.setFont('Helvetica-Bold',13); pdf.drawRightString(width-22*mm,y,f'TOTAL: INR {float(row["amount"]):,.2f}')
    pdf.setFont('Helvetica-Oblique',9); pdf.drawString(20*mm,20*mm,'Please retain this invoice for your records. This is an academic demonstration document.')
    pdf.save(); buffer.seek(0)
    return send_file(buffer,mimetype='application/pdf',as_attachment=True,download_name=f'CareSync_Invoice_{id}.pdf')

@app.route('/rooms', methods=['GET', 'POST'])
def rooms():
    conn = db()
    if request.method == 'POST':
        room_no = request.form.get('room_no', '').strip()
        room_type = request.form.get('room_type', '').strip()
        quantity_raw = request.form.get('bed_count', '1').strip()
        try:
            quantity = int(quantity_raw)
        except ValueError:
            quantity = 0
        if not room_no or not room_type or quantity < 1 or quantity > 100:
            conn.close()
            flash('Enter a room identifier, room type and a bed count between 1 and 100.')
            return redirect(url_for('rooms'))
        # Each bed is stored as an individual room row so admissions can allocate it independently.
        labels = [room_no] if quantity == 1 else [f'{room_no}-{i}' for i in range(1, quantity + 1)]
        existing = {row['room_no'] for row in conn.execute('SELECT room_no FROM rooms').fetchall()}
        duplicates = [label for label in labels if label in existing]
        if duplicates:
            conn.close()
            flash('These bed identifiers already exist: ' + ', '.join(duplicates))
            return redirect(url_for('rooms'))
        conn.executemany("INSERT INTO rooms(room_no, room_type, status) VALUES(?, ?, 'Available')",
                         [(label, room_type) for label in labels])
        log_action(conn, 'Beds added', f'{len(labels)} bed(s) added under {room_no} ({room_type})')
        notify(conn, 'New beds added', f'{len(labels)} bed(s) added under {room_no}.', 'success')
        conn.commit()
        conn.close()
        flash(f'{len(labels)} bed(s) added successfully.')
        return redirect(url_for('rooms'))
    rows = conn.execute('SELECT * FROM rooms ORDER BY room_no').fetchall()
    conn.close()
    return render_template('rooms.html', rooms=rows)

@app.route('/room/toggle/<int:id>')
def room_toggle(id):
    conn=db(); row=conn.execute('SELECT status FROM rooms WHERE id=?',(id,)).fetchone(); new='Occupied' if row['status']=='Available' else 'Available'
    conn.execute('UPDATE rooms SET status=? WHERE id=?',(new,id))
    log_action(conn,'Room status changed',f'Room {id}: {new}')
    conn.commit(); conn.close(); return redirect(url_for('rooms'))

@app.route('/emergency', methods=['GET', 'POST'])
def emergency():
    conn = db()
    if request.method == 'POST':
        first_visit = request.form.get('first_visit', 'Yes')
        patient_id = None
        patient_name = request.form.get('patient_name', '').strip()
        phone = request.form.get('phone', '').strip()
        required_fields = {
            'Contact phone': phone,
            'Reason for emergency request': request.form.get('emergency_type', '').strip(),
            'Symptoms or concern': request.form.get('symptoms', '').strip(),
            'Emergency contact name': request.form.get('emergency_contact_name', '').strip(),
            'Emergency contact phone': request.form.get('emergency_contact_phone', '').strip(),
            'Previous hospital / diagnostic centre (enter None if not applicable)': request.form.get('previous_hospital', '').strip(),
            'Heart rate / pulse (enter Not measured if unavailable)': request.form.get('heart_rate', '').strip(),
            'Blood pressure (enter Not measured if unavailable)': request.form.get('blood_pressure', '').strip(),
            'SpO2 (enter Not measured if unavailable)': request.form.get('spo2', '').strip(),
            'Temperature (enter Not measured if unavailable)': request.form.get('temperature', '').strip(),
            'Respiratory rate (enter Not measured if unavailable)': request.form.get('respiratory_rate', '').strip(),
            'Vitals source': request.form.get('vitals_source', '').strip(),
        }
        if first_visit == 'Yes':
            required_fields.update({
                'Patient name': patient_name,
                'Age': request.form.get('age', '').strip(),
                'Gender': request.form.get('gender', '').strip(),
                'Blood group (enter Unknown if not known)': request.form.get('blood_group', '').strip(),
            })
        else:
            required_fields['Existing patient record'] = request.form.get('existing_patient_id', '').strip()
        missing = [label for label, value in required_fields.items() if not value]
        if missing:
            conn.close()
            flash('Please complete all emergency information fields. Missing: ' + ', '.join(missing))
            return redirect(url_for('emergency'))

        if first_visit == 'No':
            patient_id = request.form.get('existing_patient_id') or None
            patient = conn.execute('SELECT * FROM patients WHERE id=?', (patient_id,)).fetchone() if patient_id else None
            if not patient:
                conn.close(); flash('Select a valid existing patient record.'); return redirect(url_for('emergency'))
            patient_name = patient['name']
            phone = phone or (patient['phone'] or '')
        else:
            if not patient_name:
                conn.close(); flash('Enter the new patient name.'); return redirect(url_for('emergency'))
            # Register first-time patients so later visits can be linked to the same history.
            cur = conn.execute('INSERT INTO patients(name,age,gender,phone,blood_group,created_at) VALUES(?,?,?,?,?,?)',
                (patient_name, request.form.get('age') or None, request.form.get('gender') or None,
                 phone, request.form.get('blood_group') or None, str(date.today())))
            patient_id = cur.lastrowid
            conn.execute('UPDATE patients SET patient_code=? WHERE id=?', (f'CS-{patient_id:05d}', patient_id))

        now = datetime.now().strftime('%Y-%m-%d %H:%M')
        cur = conn.execute('''INSERT INTO emergency(
            patient_name,phone,emergency_type,priority,status,created_at,symptoms,verification_status,
            patient_id,first_visit,previous_hospital,emergency_contact_name,emergency_contact_phone,
            heart_rate,blood_pressure,spo2,temperature,respiratory_rate,vitals_source,updated_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (
            patient_name, phone, request.form.get('emergency_type','').strip(), 'Unassessed', 'Active', now,
            request.form.get('symptoms','').strip(), 'Awaiting Nurse Review', patient_id, first_visit,
            request.form.get('previous_hospital','').strip(), request.form.get('emergency_contact_name','').strip(),
            request.form.get('emergency_contact_phone','').strip(), request.form.get('heart_rate','').strip(),
            request.form.get('blood_pressure','').strip(), request.form.get('spo2','').strip(),
            request.form.get('temperature','').strip(), request.form.get('respiratory_rate','').strip(),
            request.form.get('vitals_source','Patient/attendant reported'), now))
        emergency_id = cur.lastrowid
        log_action(conn, 'Emergency request registered', f"Case #{emergency_id}: {patient_name} - awaiting nurse review")
        notify(conn, 'NEW EMERGENCY REQUEST', f"Case #{emergency_id}: {patient_name}. Alert the emergency nurse immediately.", 'danger')
        conn.commit(); conn.close()
        flash('Request recorded. Alert the nurse immediately; do not wait for dashboard verification.')
        return redirect(url_for('emergency'))

    cases = conn.execute('''SELECT e.*,d.name AS doctor_name FROM emergency e
        LEFT JOIN doctors d ON d.id=e.assigned_doctor_id ORDER BY e.id DESC''').fetchall()
    patients = conn.execute('SELECT * FROM patients ORDER BY name').fetchall()
    doctors = conn.execute('SELECT * FROM doctors ORDER BY name').fetchall()
    conn.close()
    return render_template('emergency.html', cases=cases, patients=patients, doctors=doctors)


@app.route('/emergency/reports/<int:emergency_id>', methods=['POST'])
def emergency_report_upload(emergency_id):
    conn = db()
    case = conn.execute('SELECT * FROM emergency WHERE id=?', (emergency_id,)).fetchone()
    if not case:
        conn.close(); abort(404)
    uploaded = request.files.get('report_file')
    if not uploaded or not uploaded.filename:
        conn.close(); flash('Choose a report file first.'); return redirect(url_for('emergency'))
    original_name = secure_filename(uploaded.filename)
    extension = original_name.rsplit('.', 1)[-1].lower() if '.' in original_name else ''
    if extension not in ALLOWED_REPORT_EXTENSIONS:
        conn.close(); flash('Only PDF, JPG, JPEG and PNG reports are accepted.'); return redirect(url_for('emergency'))
    stored_name = f'{uuid.uuid4().hex}.{extension}'
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    uploaded.save(UPLOAD_DIR / stored_name)
    conn.execute('''INSERT INTO emergency_reports(
        emergency_id,patient_id,report_type,hospital_name,report_date,original_name,stored_name,uploaded_at
    ) VALUES(?,?,?,?,?,?,?,?)''', (
        emergency_id, case['patient_id'], request.form.get('report_type','Other').strip(),
        request.form.get('hospital_name','').strip() or 'Not provided',
        request.form.get('report_date') or None, original_name, stored_name,
        datetime.now().strftime('%Y-%m-%d %H:%M')))
    log_action(conn, 'External medical report uploaded', f"Case #{emergency_id}: {original_name}")
    notify(conn, 'Medical report added', f"A report was added to emergency case #{emergency_id} for nurse review.", 'info')
    conn.commit(); conn.close(); flash('Medical report uploaded for nurse review.')
    return redirect(url_for('emergency'))


@app.route('/emergency/report/<int:report_id>')
def emergency_report_download(report_id):
    conn = db(); report = conn.execute('SELECT * FROM emergency_reports WHERE id=?', (report_id,)).fetchone(); conn.close()
    if not report: abort(404)
    path = UPLOAD_DIR / report['stored_name']
    if not path.is_file(): abort(404)
    return send_file(path, as_attachment=True, download_name=report['original_name'])


@app.route('/nurse-dashboard')
def nurse_dashboard():
    conn = db()
    cases = conn.execute('''SELECT e.*,d.name AS doctor_name FROM emergency e
        LEFT JOIN doctors d ON d.id=e.assigned_doctor_id ORDER BY
        CASE WHEN e.status='Active' THEN 0 ELSE 1 END, e.id DESC''').fetchall()
    doctors = conn.execute('SELECT * FROM doctors ORDER BY name').fetchall()
    report_rows = conn.execute('''SELECT r.*,e.patient_name FROM emergency_reports r
        JOIN emergency e ON e.id=r.emergency_id ORDER BY r.id DESC''').fetchall()
    stats = {
        'active': conn.execute("SELECT COUNT(*) FROM emergency WHERE status='Active'").fetchone()[0],
        'awaiting': conn.execute("SELECT COUNT(*) FROM emergency WHERE verification_status='Awaiting Nurse Review'").fetchone()[0],
        'review': conn.execute("SELECT COUNT(*) FROM emergency WHERE verification_status='Needs Further Clinical Review'").fetchone()[0],
        'reports': conn.execute('SELECT COUNT(*) FROM emergency_reports').fetchone()[0]
    }
    conn.close()
    return render_template('nurse_dashboard.html', cases=cases, doctors=doctors, reports=report_rows, stats=stats)


@app.route('/emergency/verify/<int:id>', methods=['POST'])
def emergency_verify(id):
    verification = request.form.get('verification_status', 'Awaiting Nurse Review')
    allowed = {'Verified - Emergency', 'Needs Further Clinical Review', 'Not Confirmed - Follow-up Required'}
    if verification not in allowed:
        flash('Choose a valid nurse review outcome.'); return redirect(url_for('nurse_dashboard'))
    nurse = request.form.get('nurse_name', '').strip()
    notes = request.form.get('nurse_notes', '').strip()
    if not nurse or not notes:
        flash('Enter the nurse name and assessment notes before saving.'); return redirect(url_for('nurse_dashboard'))
    conn = db()
    exists = conn.execute('SELECT id FROM emergency WHERE id=?', (id,)).fetchone()
    if not exists:
        conn.close(); abort(404)
    conn.execute('UPDATE emergency SET verification_status=?,nurse_name=?,nurse_notes=?,updated_at=? WHERE id=?',
        (verification, nurse, notes, datetime.now().strftime('%Y-%m-%d %H:%M'), id))
    log_action(conn, 'Emergency nurse review', f'Case #{id}: {verification} by {nurse}')
    notify(conn, 'Emergency case reviewed', f'Case #{id} review outcome: {verification}.', 'warning')
    conn.commit(); conn.close(); flash('Nurse review saved. Clinical staff remain responsible for care decisions.')
    return redirect(url_for('nurse_dashboard'))


@app.route('/emergency/assign-doctor/<int:id>', methods=['POST'])
def emergency_assign_doctor(id):
    doctor_id = request.form.get('doctor_id') or None
    conn = db()
    doctor = conn.execute('SELECT * FROM doctors WHERE id=?', (doctor_id,)).fetchone() if doctor_id else None
    if not doctor:
        conn.close(); flash('Select a valid doctor.'); return redirect(url_for('nurse_dashboard'))
    conn.execute('UPDATE emergency SET assigned_doctor_id=?,updated_at=? WHERE id=?',
        (doctor_id, datetime.now().strftime('%Y-%m-%d %H:%M'), id))
    log_action(conn, 'Emergency doctor assigned', f'Case #{id}: {doctor["name"]}')
    notify(conn, 'Doctor assigned to emergency case', f'{doctor["name"]} was assigned to case #{id}.', 'info')
    conn.commit(); conn.close(); flash('Doctor assignment saved.')
    return redirect(url_for('nurse_dashboard'))


@app.route('/emergency/status/<int:id>', methods=['POST'])
def emergency_update_status(id):
    status = request.form.get('status', '')
    allowed = {'Active', 'Under Clinical Review', 'Doctor Assigned', 'Treatment in Progress', 'Follow-up Required', 'Closed'}
    if status not in allowed:
        flash('Choose a valid case status.'); return redirect(url_for('nurse_dashboard'))
    conn = db()
    conn.execute('UPDATE emergency SET status=?,updated_at=? WHERE id=?',
        (status, datetime.now().strftime('%Y-%m-%d %H:%M'), id))
    log_action(conn, 'Emergency status updated', f'Case #{id}: {status}')
    notify(conn, 'Emergency status updated', f'Case #{id} status changed to {status}.', 'info')
    conn.commit(); conn.close(); flash('Emergency status updated.')
    return redirect(url_for('nurse_dashboard'))


@app.route('/emergency/history/<int:patient_id>')
def emergency_patient_history(patient_id):
    conn = db()
    patient = conn.execute('SELECT * FROM patients WHERE id=?', (patient_id,)).fetchone()
    if not patient:
        conn.close(); abort(404)
    timeline = []
    for row in conn.execute('SELECT record_date AS event_date, notes AS details, "Health record" AS event_type FROM ehr WHERE patient_id=?', (patient_id,)):
        timeline.append(dict(row))
    for row in conn.execute('SELECT test_date AS event_date, test_name AS details, "Laboratory test" AS event_type FROM lab_tests WHERE patient_id=?', (patient_id,)):
        timeline.append(dict(row))
    for row in conn.execute('SELECT appointment_date AS event_date, reason AS details, "Appointment" AS event_type FROM appointments WHERE patient_id=?', (patient_id,)):
        timeline.append(dict(row))
    for row in conn.execute('''SELECT uploaded_at AS event_date,
        report_type || ' from ' || hospital_name || ' (' || original_name || ')' AS details,
        'Uploaded medical report' AS event_type FROM emergency_reports WHERE patient_id=?''', (patient_id,)):
        timeline.append(dict(row))
    for row in conn.execute('SELECT created_at AS event_date, emergency_type AS details, "Emergency request" AS event_type FROM emergency WHERE patient_id=?', (patient_id,)):
        timeline.append(dict(row))
    timeline.sort(key=lambda item: item.get('event_date') or '', reverse=True)
    reports = conn.execute('''SELECT r.* FROM emergency_reports r
        JOIN emergency e ON e.id=r.emergency_id WHERE e.patient_id=? ORDER BY r.id DESC''', (patient_id,)).fetchall()
    conn.close()
    return render_template('patient_history.html', patient=patient, timeline=timeline, reports=reports)


@app.route('/notifications')
def notifications():
    conn=db()
    rows=conn.execute('SELECT * FROM notifications ORDER BY id DESC LIMIT 100').fetchall()
    unread=conn.execute('SELECT COUNT(*) FROM notifications WHERE read_status=0').fetchone()[0]
    conn.close()
    return render_template('notifications.html',notifications=rows,unread=unread)

@app.route('/notifications/read/<int:id>',methods=['POST'])
def notification_read(id):
    conn=db(); conn.execute('UPDATE notifications SET read_status=1 WHERE id=?',(id,)); conn.commit(); conn.close()
    return redirect(url_for('notifications'))

@app.route('/notifications/read-all',methods=['POST'])
def notification_read_all():
    conn=db(); conn.execute('UPDATE notifications SET read_status=1'); conn.commit(); conn.close()
    return redirect(url_for('notifications'))

@app.route('/reports')
def reports():
    conn=db()
    monthly=conn.execute("SELECT substr(bill_date,1,7) month, ROUND(SUM(CASE WHEN status='Paid' THEN amount ELSE 0 END),2) revenue, COUNT(*) bills FROM bills GROUP BY substr(bill_date,1,7) ORDER BY month DESC LIMIT 12").fetchall()
    dept=conn.execute("SELECT d.specialization department,COUNT(a.id) appointments FROM doctors d LEFT JOIN appointments a ON a.doctor_id=d.id GROUP BY d.specialization ORDER BY appointments DESC").fetchall()
    totals={'patients':conn.execute('SELECT COUNT(*) FROM patients').fetchone()[0],'appointments':conn.execute('SELECT COUNT(*) FROM appointments').fetchone()[0],'paid':conn.execute("SELECT COALESCE(SUM(amount),0) FROM bills WHERE status='Paid'").fetchone()[0],'unpaid':conn.execute("SELECT COALESCE(SUM(amount),0) FROM bills WHERE status='Unpaid'").fetchone()[0],'occupancy':conn.execute("SELECT COUNT(*) FROM rooms WHERE status='Occupied'").fetchone()[0],'beds':conn.execute("SELECT COUNT(*) FROM rooms").fetchone()[0]}
    conn.close()
    return render_template('reports.html',monthly=monthly,departments=dept,totals=totals)

@app.route('/audit')
def audit():
    conn=db(); rows=conn.execute('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100').fetchall(); conn.close()
    return render_template('audit.html',logs=rows)

@app.route('/global-search')
def global_search():
    q=request.args.get('q','').strip()
    conn=db()
    patients=conn.execute('SELECT id,name,phone,patient_code FROM patients WHERE name LIKE ? OR phone LIKE ? OR patient_code LIKE ? LIMIT 20',(f'%{q}%',f'%{q}%',f'%{q}%')).fetchall() if q else []
    doctors=conn.execute('SELECT id,name,specialization FROM doctors WHERE name LIKE ? OR specialization LIKE ? LIMIT 20',(f'%{q}%',f'%{q}%')).fetchall() if q else []
    conn.close()
    return render_template('search.html',q=q,patients=patients,doctors=doctors)

@app.route('/export/patients.csv')
def export_patients():
    import csv, io
    from flask import Response
    conn=db(); rows=conn.execute('SELECT patient_code,name,age,gender,phone,blood_group,created_at FROM patients ORDER BY id').fetchall(); conn.close()
    output=io.StringIO(); writer=csv.writer(output); writer.writerow(['Patient ID','Name','Age','Gender','Phone','Blood Group','Registered']); writer.writerows([tuple(r) for r in rows])
    return Response(output.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=caresync_patients.csv'})

@app.route('/export/reports.csv')
def export_reports():
    import csv, io
    from flask import Response
    conn=db(); rows=conn.execute('SELECT bill_date,description,amount,status FROM bills ORDER BY id DESC').fetchall(); conn.close()
    output=io.StringIO(); writer=csv.writer(output); writer.writerow(['Date','Description','Amount','Status']); writer.writerows([tuple(r) for r in rows])
    return Response(output.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=caresync_billing_report.csv'})

if __name__=='__main__':
    init_db()
    app.run(host='127.0.0.1', port=5000, debug=False)
