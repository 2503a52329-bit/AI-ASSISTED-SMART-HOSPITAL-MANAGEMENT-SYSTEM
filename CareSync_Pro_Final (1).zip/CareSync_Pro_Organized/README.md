# CareSync Pro – Smart Hospital Management System

A local academic demonstration project made with **Python, Flask, SQLite, HTML, CSS and Chart.js**.

## Project structure

```text
CareSync_Pro_Organized/
├── app.py                 # Flask application and database setup
├── requirements.txt       # Python dependency list
├── START_CARESYNC.bat     # Windows one-click setup and launch
├── README.md              # Setup and usage guide
├── .gitignore             # Excludes local database and Python cache
├── templates/             # HTML pages
└── static/                # CSS and JavaScript
```

## Run on Windows using VS Code

### First time
1. Download and extract `CareSync_Pro_Organized.zip`.
2. Open the extracted **CareSync_Pro_Organized** folder in VS Code (File → Open Folder).
3. Open Terminal → New Terminal. Confirm the terminal is inside the folder containing `app.py`.
4. Check Python is installed:
   ```powershell
   python --version
   ```
   If that command is not recognised, try `py --version`.
5. Install the required package:
   ```powershell
   python -m pip install -r requirements.txt
   ```
   If using the `py` launcher, run `py -m pip install -r requirements.txt`.
6. Start the website:
   ```powershell
   python app.py
   ```
   Or use `py app.py` if you used the `py` launcher.
7. Keep the terminal open and visit **http://127.0.0.1:5000** in Chrome or Edge.
8. To stop the server, return to the terminal and press **Ctrl + C**.

### Easier option
Double-click `START_CARESYNC.bat`. It creates a local virtual environment, installs Flask, and starts the application. The first run needs an internet connection to install Flask.

## Features included

- Dashboard with hospital overview and operational metrics
- Patient registration, search and CSV export
- Doctor directory and availability
- Appointment booking and scheduling checks
- Admissions, room allocation and discharge workflow
- Electronic health record notes
- Pharmacy inventory and stock visibility
- Laboratory test requests, results and downloadable PDF reports
- Billing, payment tracking and downloadable PDF invoices
- Beds and room availability
- Emergency request intake with nurse-review recording and clinical escalation notes
- AI department guidance demo
- Notifications, global search, analytics and activity log

## Important notes

- The application creates `hospital.db` automatically in the project folder when first started.
- Existing database data is retained between runs. To reset demo data, stop the app and remove `hospital.db`; the next run creates a fresh database.
- Use fictional sample data only. This is an academic prototype, not a production hospital system. It does not provide production authentication, role-based access control, or clinical decision-making. Emergency assessment and clinical decisions must be handled by qualified healthcare professionals.
- The AI Assistant is an educational department-routing demonstration, not a diagnosis or treatment tool.


## New dashboard updates

- **Laboratory:** complete a test by entering the verified result; the completed row displays **Download PDF**. Pending tests cannot be downloaded as final reports.
- **Billing:** every bill has a **Download PDF** invoice action, whether paid or unpaid.
- **Emergency:** requests enter **Awaiting Nurse Review**. A nurse records an in-person assessment outcome and notes. The app does not decide whether a patient is truly in an emergency and must never be used to delay urgent care. Alert the on-site emergency team immediately when someone appears seriously unwell; follow the hospital's clinical protocols.

The emergency workflow is a demonstration only. It does not include secure staff login, identity verification, audit-grade signatures, or integration with a hospital alert system. Add those before any real-world use. Use fictional data only.

## Emergency workflow expansion

- **First-time / existing patient:** first-time emergency submissions create a patient profile; existing patients are linked through their CareSync patient record.
- **External medical reports:** upload PDF, JPG, JPEG or PNG files from this hospital, another hospital or a diagnostic centre. Record the source institution, report type and report date. Files are stored outside the public `static` folder in `instance/medical_reports/` and are downloaded through a Flask route.
- **Vital information:** optional heart rate/pulse, blood pressure, SpO2, temperature and respiratory-rate fields, with a source label. The app does not interpret these values or use them to reject/downgrade requests.
- **Nurse dashboard:** `/nurse-dashboard` displays active cases, patient information, uploaded reports, nurse review, doctor assignment and case status.
- **Patient timeline:** existing patient history combines EHR notes, lab tests, appointments, emergency requests and uploaded reports.
- **In-app notifications:** new requests, report uploads, nurse reviews, doctor assignments and status changes create notification-centre entries.
- **Emergency contact:** optional trusted contact name and phone number.

Uploaded report types are limited to PDF and common image formats and each request is limited to 10 MB. This academic prototype still has no staff authentication or role-based access control; the nurse dashboard and report-download routes are not protected by login. Do not use real patient records or deploy this version for clinical care. Add authenticated patient/staff accounts, permissions, secure deployment, encrypted storage, backups and institution-approved clinical workflows before any real-world use. Notifications are in-app only and do not send SMS, email, push alerts or call emergency services.
