@echo off
setlocal
cd /d "%~dp0"
echo =====================================
echo       CareSync Pro - Launcher
echo =====================================
where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py"
) else (
    set "PY=python"
)
%PY% --version
if errorlevel 1 (
    echo Python was not found. Install Python 3 and enable Add Python to PATH.
    pause
    exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    %PY% -m venv .venv
    if errorlevel 1 goto error
)
echo Installing required packages...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error
echo Starting CareSync Pro...
echo Open http://127.0.0.1:5000 in your browser.
".venv\Scripts\python.exe" app.py
goto end
:error
echo Setup failed. Check the error above and try the README steps.
pause
:end
endlocal
